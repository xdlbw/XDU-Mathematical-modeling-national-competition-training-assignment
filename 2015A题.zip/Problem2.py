import numpy as np
import pandas as pd
from MY_GET_DATA import my_get_data  # 对附件数据的获取


def get_cwj(day):
    # 计算赤纬角（返回弧度）
    # 参数：day为一年中的第几天
    return (23.45*np.pi/180)*np.sin(2*np.pi*(284+day)/365)


def get_sj(lon, loctime):
    # 计算时角（返回弧度）
    # 参数：lon为经度(度数),loctime为当地时间
    return ((lon-120)/15 + loctime - 12)*np.pi/12


def get_gdj(lat, cwj, sj):
    # 计算高度角（返回弧度）
    # 参数：lat为纬度(度数)，cwj为赤纬角(弧度),sj为时角(弧度)
    return np.arcsin(np.sin(lat*np.pi/180)*np.sin(cwj) + np.cos(lat*np.pi/180)*np.cos(cwj)*np.cos(sj))


def cal_gdjs(df, lat, lon, day):
    # 计算一个df、一个lat、lon、day对应的一组gdj高度角
    dff = df.iloc[:, :]
    cwj = get_cwj(day)
    dff['sj'] = [get_sj(lon, loctime) for loctime in dff['z(hour)']]
    dff['gdj'] = [get_gdj(lat, cwj, sj) for sj in dff['sj']]
    return dff['gdj']


def cal_Lsum(df, gdjs, len):
    # 计算一组L与一组L*对应的结果 (len为杆长)
    Ls = len/np.tan(gdjs)
    Lsum = 0
    for idx in df.index[:-1]:
        Lsum += (Ls[idx+1]/Ls[idx] - df.loc[idx+1, 'len']/df.loc[idx, 'len'])**2
    return Lsum


def get_spot(lons, lats, idxs):
    spot = []
    for idx in idxs:
        lon_cur = lons[int(np.ceil((idx+1) / len(lats))) - 1]
        lat_cur = lats[(idx+1) % len(lats) - 1]
        spot.append((lon_cur, lat_cur))
    return spot


if __name__ == '__main__':
    L = 3  # 杆长
    day = 108
    df0, df1, df2 = my_get_data()  # 数据获取，分别对应附件1-3的数据
    jingdu = 0.5  # 经纬的精度
    lons = np.arange(99, 115, jingdu)
    lats = np.arange(-10, 30, jingdu)
    Lsums = []

    for lon in lons:
        for lat in lats:
            gdjs = cal_gdjs(df0, lat, lon, day)
            flag = False
            for i in gdjs:
                if i <= 0 or i >= np.pi/2:
                    flag = True  # 捕捉到小于等于0的角度 或 大于等于pi/2
                    break
            if flag:
                Lsums.append(1e10)  # 一个表示无效的极大值
            else:
                Lsums.append(cal_Lsum(df0, gdjs, L))

    Lsums_ser = pd.Series(Lsums)
    Lsums_ser.sort_values(inplace=True, ascending=True)
    spot_num = 50  # 选定的目标地点范围数目
    spot = get_spot(lons, lats, Lsums_ser.index[:spot_num])
    # for i in spot:
    #     print(i)
    # print(Lsums_ser.values[:spot_num])

    list_e8 = []  # 误差为10-8数量级的点
    list_e7 = []  # 误差为10-7数量级的点
    for idx, i in enumerate(Lsums_ser.index):
        if Lsums_ser[i] < 1e-7:
            list_e8.append(spot[idx])
        elif Lsums_ser[i] < 1e-6:
            list_e7.append(spot[idx])
        else:
            break
    print('误差为10-8：', list_e8)
    print('误差为10-7：', list_e7)
    lons_8 = np.average([i[0] for i in list_e8])
    lats_8 = np.average([i[1] for i in list_e8])
    lons_7_f = np.average([i[0] for i in list_e7 if i[1] < 0])
    lats_7_f = np.average([i[1] for i in list_e7 if i[1] < 0])
    lons_7_z = np.average([i[0] for i in list_e7 if i[1] >= 0])
    lats_7_z = np.average([i[1] for i in list_e7 if i[1] >= 0])
    lons_8_7_z = np.average([i[0] for i in list_e8] + [i[0] for i in list_e7 if i[1] >= 0])
    lats_8_7_z = np.average([i[1] for i in list_e8] + [i[1] for i in list_e7 if i[1] >= 0])
    print('误差为10-8：', lons_8, lats_8)  # 误差为10-8数量级的点的均值
    print('误差为10-7,纬度为负：', lons_7_f, lats_7_f)  # 误差为10-7数量级且维度为负的点的均值
    print('误差为10-7,纬度为正：', lons_7_z, lats_7_z)  # 误差为10-7数量级且维度为正的点的均值
    print('误差为10-8、10-7,纬度为正：', lons_8_7_z, lats_8_7_z)  # 误差为10-8、10-7数量级且维度为正的点的均值

