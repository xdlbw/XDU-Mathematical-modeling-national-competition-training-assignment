# coding: utf-8
import numpy as np
import pandas as pd


# 提取数据
def get_data(path):
    ghl_frame = pd.read_excel(path, '供应商的供货量（m³）')
    dhl_frame = pd.read_excel(path, '企业的订货量（m³）')
    ghl_sum = np.sum(ghl_frame.iloc[:, 2:], axis=1)
    # with open('每个供应商的总供应量.txt', mode='w') as f:
    #     for i in ghl_sum:
    #         f.write(str(i)+'\n')
    ghl_average = []
    temp_tran = {
        'A':0.6,
        'B':0.66,
        'C':0.72
    }
    for i in ghl_frame.index:
        temp = []
        for j in range(2, ghl_frame.shape[1]):
            if ghl_frame.iloc[i, j] > 0:
                temp.append(ghl_frame.iloc[i, j])
        ghl_average.append(np.mean(temp) / temp_tran[ghl_frame.iloc[i, 1]])
    # with open('每个供应商的平均供应量.txt', mode='w') as f:
    #     for i in ghl_average:
    #         f.write(str(i)+'\n')
    ghl_lxx_data = []  # 供货量连续性
    for i in ghl_frame.index:
        temp = ghl_frame.iloc[i, 2:]
        temp1 = [int(j > 0) for j in temp]
        ghl_lxx_data.append(np.var(temp1))  # np.var()用于计算方差
    # with open('每个供应商的供应量连续性.txt', mode='w') as f:
    #     for i in ghl_lxx_data:
    #         f.write(str(i)+'\n')
    # dhl_sum = np.sum(dhl_frame.iloc[:, 2:], axis=1)
    # with open('每个供应商的总订货量.txt', mode='w') as f:
    #     for i in dhl_sum:
    #         f.write(str(i)+'\n')
    # 供应满足比
    sat_rate_data = []
    for i in ghl_frame.index:
        sat_times = 0
        dh_times = 0
        for j in range(2, ghl_frame.shape[1]):
            if dhl_frame.iloc[i, j] > 0:
                dh_times += 1
                if ghl_frame.iloc[i, j] >= dhl_frame.iloc[i, j]:
                    sat_times += 1
        sat_rate_data.append(sat_times / dh_times)
    # with open('每个供应商供应满足比例.txt', mode='w') as f:
    #     for i in sat_rate_data:
    #         f.write(str(i)+'\n')

    sigma = []  # 供货稳定性
    for i in ghl_frame.index:
        temp = 0
        for j in range(2, ghl_frame.shape[1]):
            temp += (ghl_frame.iloc[i, j] - dhl_frame.iloc[i, j])**2
        sigma.append(temp / (ghl_frame.shape[1] - 2))
    # with open('供货稳定性.txt', mode='w') as f:
    #     for i in sigma:
    #         f.write(str(i)+'\n')

    # 每个供应商在240周里的单次供应量最大值
    ghl_max = np.max(ghl_frame.iloc[:, 2:], axis=1)
    # with open('每个供应商的单次供应量最大值.txt', mode='w') as f:
    #     for i in ghl_max:
    #         f.write(str(i)+'\n')
    return ghl_frame, np.array(ghl_sum), np.array(ghl_average), np.array(sigma), np.array(ghl_lxx_data), np.array(sat_rate_data), ghl_max

# 数据整合：
ghl_frame, ghl_sum, ghl_average, sigma, ghl_lxx_data, sat_rate_data, ghl_max = get_data(path='../附件1 近5年402家供应商的相关数据.xlsx')
Z = {
    'zl': ghl_sum,  # 供货总量 极大型
    'pj': ghl_average,  # 平均供货量 极大型
    'wdx': sigma,  # 供货稳定性 极小性
    'lxx': ghl_lxx_data,  # 供货连续性 极小性
    'mzb': sat_rate_data  # 供应满足比 极大型
}


# # 单纯的TOPSIS
# # 数据正向化处理
# def get_zxh_T(R, mode='+'):
#     if mode == '+':  # 极大型
#         return R
#     else:  # 极小型
#         return np.max(R) - R
# Z_std_T = pd.DataFrame(Z)
# Z_std_T['zl'] = get_zxh_T(Z['zl'], '+')
# Z_std_T['pj'] = get_zxh_T(Z['pj'], '+')
# Z_std_T['wdx'] = get_zxh_T(Z['wdx'], '-')
# Z_std_T['lxx'] = get_zxh_T(Z['lxx'], '-')
# Z_std_T['mzb'] = get_zxh_T(Z['mzb'], '+')
# # 再标准化
# for j in range(Z_std_T.shape[1]):
#     temp = np.sqrt(np.sum(Z_std_T.iloc[:, j]**2))
#     Z_std_T.iloc[:, j] /= temp
# # 最优解与最劣解
# Z_best_T = pd.DataFrame(np.zeros((1, Z_std_T.shape[1])), columns=Z_std_T.columns)
# Z_best_T['zl'] = np.max(Z_std_T.loc[:, 'zl'])
# Z_best_T['pj'] = np.max(Z_std_T.loc[:, 'pj'])
# Z_best_T['wdx'] = np.max(Z_std_T.loc[:, 'wdx'])
# Z_best_T['lxx'] = np.max(Z_std_T.loc[:, 'lxx'])
# Z_best_T['mzb'] = np.max(Z_std_T.loc[:, 'mzb'])
# Z_worst_T = pd.DataFrame(np.zeros((1, Z_std_T.shape[1])), columns=Z_std_T.columns)
# Z_worst_T['zl'] = np.min(Z_std_T.loc[:, 'zl'])
# Z_worst_T['pj'] = np.min(Z_std_T.loc[:, 'pj'])
# Z_worst_T['wdx'] = np.min(Z_std_T.loc[:, 'wdx'])
# Z_worst_T['lxx'] = np.min(Z_std_T.loc[:, 'lxx'])
# Z_worst_T['mzb'] = np.min(Z_std_T.loc[:, 'mzb'])
# # 衡量距离
# d_best_T = pd.DataFrame(np.zeros((Z_std_T.shape[0], 1)))
# for i in range(Z_std_T.shape[0]):
#     temp = 0
#     for j in range(Z_std_T.shape[1]):
#         temp += (Z_best_T.iloc[0, j] - Z_std_T.iloc[i, j])**2
#     d_best_T.iloc[i, 0] = np.sqrt(temp)
# d_worst_T = pd.DataFrame(np.zeros((Z_std_T.shape[0], 1)))
# for i in range(Z_std_T.shape[0]):
#     temp = 0
#     for j in range(Z_std_T.shape[1]):
#         temp += (Z_worst_T.iloc[0, j] - Z_std_T.iloc[i, j])**2
#     d_worst_T.iloc[i, 0] = np.sqrt(temp)
# # 评分
# score_T = d_worst_T / (d_best_T+d_worst_T)
# #排序
# # score_T.sort_values(by=0, ascending=False)
# result_T = score_T.sort_values(by=0, ascending=False).iloc[:50, 0]
# with open('1_TOPSIS结果.txt', mode='w') as f:
#     f.write('供应商ID  得分\n')
#     for idx, value in result_T.items():
#         f.write('S%03d    ' % (idx+1)+f'{value}\n')


# 先熵权法，再结合TOPSIS
# 数据标准化处理
def get_std_W(R, mode='+'):
    if mode == '+':  # 正指标
        return (R-np.min(R))/(np.max(R)-np.min(R))
    else:  # 负指标
        return (np.max(R)-R)/(np.max(R)-np.min(R))
Z_std_W = pd.DataFrame(Z)
Z_std_W['zl'] = get_std_W(Z['zl'], '+')
Z_std_W['pj'] = get_std_W(Z['pj'], '+')
Z_std_W['wdx'] = get_std_W(Z['wdx'], '-')
Z_std_W['lxx'] = get_std_W(Z['lxx'], '-')
Z_std_W['mzb'] = get_std_W(Z['mzb'], '+')
# 各指标在各方案下的比值
p_W = pd.DataFrame(np.zeros(Z_std_W.shape), columns=Z_std_W.columns)
for j in range(p_W.shape[1]):
    p_W.iloc[:, j] = Z_std_W.iloc[:, j] / np.sum(Z_std_W.iloc[:, j])
# 各指标的信息熵
p_W += 1e-7  # 加上正向平移量，避免对数运算出问题
e_W = pd.DataFrame(np.zeros((1, p_W.shape[1])), columns=p_W.columns)
for j in range(e_W.shape[1]):
    e_W.iloc[0, j] = - np.sum(p_W.iloc[:, j]*np.log(p_W.iloc[:, j])) / np.log(p_W.shape[0])
# 通过信息熵计算各个指标的权重
w_W = pd.DataFrame(np.zeros((1, Z_std_W.shape[1])), columns=Z_std_W.columns)
for j in range(w_W.shape[1]):
    w_W.iloc[0, j] = (1 - e_W.iloc[0, j]) / (e_W.shape[1] - np.sum(e_W.iloc[0, :]))
# 下面进行其TOPSIS评价
# 正理想解
pis = pd.DataFrame(np.array([1, 1, 0, 0, 1]).reshape(1, Z_std_W.shape[1]), columns=Z_std_W.columns)
# 负理想解
nis = pd.DataFrame(np.array([0, 0, 1, 1, 0]).reshape(1, Z_std_W.shape[1]), columns=Z_std_W.columns)
# 衡量距离
d_best_W = pd.DataFrame(np.zeros((Z_std_W.shape[0], 1)))
for i in range(d_best_W.shape[0]):
    temp = 0
    for j in range(Z_std_W.shape[1]):
        temp += w_W.iloc[0, j]*((pis.iloc[0, j]-Z_std_W.iloc[i, j])**2)
    d_best_W.iloc[i, 0] = np.sqrt(temp)
d_worst_W = pd.DataFrame(np.zeros((Z_std_W.shape[0], 1)))
for i in range(d_worst_W.shape[0]):
    temp = 0
    for j in range(Z_std_W.shape[1]):
        temp += w_W.iloc[0, j]*((nis.iloc[0, j]-Z_std_W.iloc[i, j])**2)
    d_worst_W.iloc[i, 0] = np.sqrt(temp)
# 评分
score_W = d_worst_W / (d_best_W+d_worst_W)
#排序
# score_W.sort_values(by=0, ascending=False)
result_W = score_W.sort_values(by=0, ascending=False).iloc[:50, 0]
with open('1_熵权法结果.txt', mode='w') as f:
    f.write('供应商ID  得分\n')
    for idx, value in result_W.items():
        f.write('S%03d    ' % (idx+1)+f'{value}\n')
